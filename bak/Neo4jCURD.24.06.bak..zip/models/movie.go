package models

import (
	"errors"
	"strings"
)

func GetMovie(movieId string) (m *Movie, err error) {
	/*if m, ok := MovieList[movieId]; ok {
		return m, nil
	}*/

	m, err = getNodeMovie(movieId)
	if err == nil {
		return m, nil
	}

	return nil, errors.New("Movie not exists")
}

func GetAllMovies() map[string]*Movie {
	return getAllNodeMovies() //MovieList
}

func AddMovie(m Movie) string {
	for _, i := range MovieList {
		if strings.Compare(m.MovieId, i.MovieId) == 0 {
			return "MovieId exists"
		}
	}

	MovieList[m.MovieId] = &m
	return m.MovieId
}

func UpdateMovie(movieId string, m *Movie) (movie *Movie, err error) {
	if temp_movie, ok := MovieList[movieId]; ok {
		if m.Countries != "" {
			temp_movie.Countries = m.Countries
		}
		if m.ImdbId != "" {
			temp_movie.ImdbId = m.ImdbId
		}
		if m.ImdbRating != "" {
			temp_movie.ImdbRating = m.ImdbRating
		}
		if m.ImdbVotes != "" {
			temp_movie.ImdbVotes = m.ImdbVotes
		}
		if m.MovieId != "" {
			temp_movie.MovieId = m.MovieId
		}
		if m.Plot != "" {
			temp_movie.Plot = m.Plot
		}
		if m.Poster != "" {
			temp_movie.Poster = m.Poster
		}
		if m.Released != "" {
			temp_movie.Released = m.Released
		}
		if m.Runtime != "" {
			temp_movie.Runtime = m.Runtime
		}
		if m.Title != "" {
			temp_movie.Title = m.Title
		}
		if m.TmdbId != "" {
			temp_movie.TmdbId = m.TmdbId
		}
		if m.Year != "" {
			temp_movie.Year = m.Year
		}
		if m.Languages != "" {
			temp_movie.Languages = m.Languages
		}

		return temp_movie, nil
	}

	return nil, errors.New("Movie not exist")
}

func DeleteMovie(movieId string) {
	delete(MovieList, movieId)
}
