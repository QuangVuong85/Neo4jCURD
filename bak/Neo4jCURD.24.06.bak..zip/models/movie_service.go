package models

import (
	"Neo4jCURD/config"
	"fmt"
	"github.com/neo4j/neo4j-go-driver/neo4j"
	"log"
)

var (
	MovieList map[string]*Movie
)

type Movies struct {
	Counts     int      `json:"counts"`
	ListMovies []*Movie `json:"movies"`
}

type Movie struct {
	Countries  string `json:"countries"`
	ImdbId     string `json:"imdb_id"`
	ImdbRating string `json:"imdb_rating"`
	ImdbVotes  string `json:"imdb_votes"`
	Languages  string `json:"languages"`
	MovieId    string `json:"movie_id"`
	Plot       string `json:"plot"`
	Poster     string `json:"poster"`
	Released   string `json:"released"`
	Runtime    string `json:"runtime"`
	Title      string `json:"title"`
	TmdbId     string `json:"tmdb_id"`
	Year       string `json:"year"`
}

/*type country struct {
	name string `json:"name"`
}

type language struct {
	name string `json:"name"`
}*/

func init() {
	//getAllNodeMovies()
}

// edit node movie

// delete node movie

// add node movie
func addNodeMovie()  {
	
}

// get node movie
func getNodeMovie(movieId string) (*Movie, error) {
	query := `
			MATCH (m:Movie)
			WHERE 
				m.movieId = $movieid
			RETURN
				m.countries as countries,
				m.imdbId as imdbId,
				m.imdbRating as imdbRating,
				m.imdbVotes as imdbVotes,
				m.languages as languages,
				m.movieId as movieId,
				m.plot as plot,
				m.poster as poster,
				m.released as released,
				m.runtime as runtime,
				m.title as title,
				m.tmdbId as tmdbId,
				m.year as year`

	mapParms := map[string] interface{} {
		"movieid": movieId,
	}

	result, err := resultQueryNodeMovies(query, mapParms)
	if err != nil {
		return nil, err
	}

	var temp_Movie *Movie
	if result.Next() {
		countries := fmt.Sprintf("%v", result.Record().GetByIndex(0))
		imdbId := fmt.Sprintf("%v", result.Record().GetByIndex(1))
		imdbRating := fmt.Sprintf("%v", result.Record().GetByIndex(2))
		imdbVotes := fmt.Sprintf("%v", result.Record().GetByIndex(3))
		languages := fmt.Sprintf("%v", result.Record().GetByIndex(4))
		movieId := fmt.Sprintf("%v", result.Record().GetByIndex(5))
		plot := fmt.Sprintf("%v", result.Record().GetByIndex(6))
		poster := fmt.Sprintf("%v", result.Record().GetByIndex(7))
		released := fmt.Sprintf("%v", result.Record().GetByIndex(8))
		runtime := fmt.Sprintf("%v", result.Record().GetByIndex(9))
		title := fmt.Sprintf("%v", result.Record().GetByIndex(10))
		tmdbId := fmt.Sprintf("%v", result.Record().GetByIndex(11))
		year := fmt.Sprintf("%v", result.Record().GetByIndex(12))

		temp_Movie = &Movie{
			countries,
			imdbId,
			imdbRating,
			imdbVotes,
			languages,
			movieId,
			plot,
			poster,
			released,
			runtime,
			title,
			tmdbId,
			year}
	}

	return temp_Movie, nil
}

// get all node movies
func getAllNodeMovies() (map[string]*Movie) {
	MovieList := make(map[string]*Movie)

	query := `
			MATCH (m:Movie)
			RETURN
				m.countries as countries,
				m.imdbId as imdbId,
				m.imdbRating as imdbRating,
				m.imdbVotes as imdbVotes,
				m.languages as languages,
				m.movieId as movieId,
				m.plot as plot,
				m.poster as poster,
				m.released as released,
				m.runtime as runtime,
				m.title as title,
				m.tmdbId as tmdbId,
				m.year as year
			LIMIT $limit`
	mapParams := map[string]interface{} {
		"limit": 3,
	}
	result, err := resultQueryNodeMovies(query, mapParams)
	if err != nil {
		log.Println("", err)
	}

	for result.Next() {
		//fmt.Println(fmt.Sprintf("%v", result.Record().GetByIndex(5)))
		//fmt.Println(len(countries))
		/*for _, item := range countries {
			fmt.Println(item)
		}*/

		countries := fmt.Sprintf("%v", result.Record().GetByIndex(0))
		imdbId := fmt.Sprintf("%v", result.Record().GetByIndex(1))
		imdbRating := fmt.Sprintf("%v", result.Record().GetByIndex(2))
		imdbVotes := fmt.Sprintf("%v", result.Record().GetByIndex(3))
		languages := fmt.Sprintf("%v", result.Record().GetByIndex(4))
		movieId := fmt.Sprintf("%v", result.Record().GetByIndex(5))
		plot := fmt.Sprintf("%v", result.Record().GetByIndex(6))
		poster := fmt.Sprintf("%v", result.Record().GetByIndex(7))
		released := fmt.Sprintf("%v", result.Record().GetByIndex(8))
		runtime := fmt.Sprintf("%v", result.Record().GetByIndex(9))
		title := fmt.Sprintf("%v", result.Record().GetByIndex(10))
		tmdbId := fmt.Sprintf("%v", result.Record().GetByIndex(11))
		year := fmt.Sprintf("%v", result.Record().GetByIndex(12))

		temp_Movie := &Movie{
			countries,
			imdbId,
			imdbRating,
			imdbVotes,
			languages,
			movieId,
			plot,
			poster,
			released,
			runtime,
			title,
			tmdbId,
			year}

		MovieList[movieId] = temp_Movie
	}

	return MovieList
}

func resultQueryNodeMovies(query string, mapParams map[string]interface{}) (neo4j.Result, error)  {
	driver, session, err := config.Connect2Neo4j()
	if err != nil {
		log.Println("Error connecting to Database: ", err)
	}
	defer driver.Close()
	defer session.Close()

	result, err := session.Run(query, mapParams)
	if err != nil {
		log.Println("", err)
		return nil, err
	}

	return result, err
}


