package config

import (
	"github.com/astaxie/beego"
	"github.com/neo4j/neo4j-go-driver/neo4j"
)

// Connect to Neo4j use neo4j-go-driver
func Connect2Neo4j() (neo4j.Driver, neo4j.Session, error) {
	configForNeo4j := func(config *neo4j.Config) {
		config.Encrypted = true
	}

	driver, err := neo4j.NewDriver(
		beego.AppConfig.String("URI"),
		neo4j.BasicAuth(
			beego.AppConfig.String("USER"),
			beego.AppConfig.String("PASSWORD"), ""),
		configForNeo4j)
	if err != nil {
		return nil, nil, err
	}

	sessionConfig := neo4j.SessionConfig{AccessMode: neo4j.AccessModeWrite}
	session, err := driver.NewSession(sessionConfig)
	if err != nil {
		return nil, nil, err
	}

	return driver, session, nil
}
